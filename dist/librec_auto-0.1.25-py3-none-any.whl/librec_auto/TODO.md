* librec-auto TODO

- Upgrade to LibRec 3.0
- clean up / document
- platform-sensitive install (paths for Java, Python)
- Separate LibRec install (or detect)
- sanity check on eval-only: has the config changed too much?
- detect: item-based similarity vs user-based, detect ranking vs prediction metrics
- P-Fairness metrics (LibRec)
- C-Fairness metrics (LibRec)
- Configuration includes
- Interface to other systems: PSL
- Sub-group metrics (long-tail, protected group, etc.)
- Fix status mechanism to stay up-to-date with different manipulations
- Prompt in purge command should be specific about what will be removed.

* librec-auto BUGS
- 

* librec-auto UNTESTED
- Post scripts
- Re-ranking